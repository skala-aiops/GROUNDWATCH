import { afterEach, describe, expect, it, vi } from "vitest";
import {
  predictionLabel,
  confirmedUnit,
  initialStationId,
  post,
  request,
} from "./api";

afterEach(() => vi.unstubAllGlobals());
describe("unified station requests preserve API namespaces", () => {
  it("keeps legacy actions on v1 while station reads and experimental actions use v2", async () => {
    const fetcher = vi
      .fn()
      .mockImplementation(
        async () =>
          new Response(JSON.stringify({ status: "ok" }), { status: 200 }),
      );
    vi.stubGlobal("fetch", fetcher);
    await request("/api/v2/network/stations?mode=current");
    await post("/api/v2/stations/fixture/training-jobs", { variant: "M0" });
    await post("/models/11110/rollback", { reason: "TEST ONLY" });
    expect(fetcher.mock.calls.map((c) => c[0])).toEqual([
      "/api/v2/network/stations?mode=current",
      "/api/v2/stations/fixture/training-jobs",
      "/api/v1/models/11110/rollback",
    ]);
  });
  it("keeps health requests outside either versioned domain", async () => {
    const fetcher = vi
      .fn()
      .mockImplementation(async () => new Response("{}", { status: 200 }));
    vi.stubGlobal("fetch", fetcher);
    await request("/health/ready");
    expect(fetcher.mock.calls[0][0]).toBe("/health/ready");
  });
});

describe("station readiness display", () => {
  const rows = [
    {
      station_id: "seoul:test",
      legacy_district_code: "11110",
      model_ready: true,
      model_status: "active",
      prediction: 1,
      observed_date: "2024-03-18",
    },
    {
      station_id: "kwater:test",
      model_ready: true,
      model_status: "active",
      prediction: 2,
      prediction_method: "lstm",
      observed_date: "2026-10-07",
    },
  ];
  it("starts on the freshest ready model and preserves subsequent user selection", () => {
    expect(initialStationId(rows, "")).toBe("kwater:test");
    expect(initialStationId(rows, "seoul:test")).toBe("seoul:test");
    expect(initialStationId(rows, "11110")).toBe("seoul:test");
  });
  it("does not present unknown unit markers as physical units", () => {
    expect(confirmedUnit("unverified")).toBe("");
    expect(confirmedUnit("unknown")).toBe("");
    expect(confirmedUnit("el.m")).toBe("el.m");
  });
});

describe("prediction issuance timing labels", () => {
  it("compares the target with the KST issuance date rather than the input date", () => {
    expect(
      predictionLabel({
        forecast_date: "2026-10-08",
        prediction_issued_at: "2026-10-08T02:30:00Z",
      }),
    ).toBe("당일 수위 추정");
    expect(
      predictionLabel({
        forecast_date: "2026-10-08",
        prediction_issued_at: "2026-10-07T16:00:00Z",
      }),
    ).toBe("당일 수위 추정");
    expect(
      predictionLabel({
        forecast_date: "2026-10-09",
        prediction_issued_at: "2026-10-08T02:30:00Z",
      }),
    ).toBe("다음 날 수위 예측");
    expect(
      predictionLabel({
        forecast_date: "2026-10-07",
        prediction_issued_at: "2026-10-08T02:30:00Z",
      }),
    ).toBe("저장된 수위 추정");
  });
  it("does not imply issuance for persistence or missing issuance evidence", () => {
    expect(predictionLabel({ prediction_method: "persistence" })).toBe(
      "직전 관측값 기준 비교",
    );
    expect(predictionLabel({ forecast_date: "2026-10-08" })).toBe(
      "저장된 수위 추정",
    );
  });
});
